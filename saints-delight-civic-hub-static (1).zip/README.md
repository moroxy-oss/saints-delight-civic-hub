# Saints Delight Civic Hub — Static Website

This is a no-build, no-database version of the supplied Google AI Studio project.

## What is included
- Responsive public website
- Home, Represent Us, Elections, Government, Get Help, Calendar, Our History and Sources views
- Working navigation
- Working external links
- Candidate and government reference links
- All concrete external URLs found in the supplied source project preserved in Sources
- No login, API key or paid app builder required

## Free hosting
The easiest free option is GitHub Pages:
1. Create a public GitHub repository.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Select the `main` branch and `/ (root)`.
5. Save and share the generated `github.io` URL.

GitHub Pages hosts static HTML/CSS/JavaScript directly from a repository.
